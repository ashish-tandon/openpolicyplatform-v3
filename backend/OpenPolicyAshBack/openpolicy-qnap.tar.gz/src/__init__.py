# OpenPolicy Database System
__version__ = "1.0.0"